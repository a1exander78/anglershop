-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Мар 15 2022 г., 21:04
-- Версия сервера: 8.0.19
-- Версия PHP: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `anglershop`
--

-- --------------------------------------------------------

--
-- Структура таблицы `basket`
--

CREATE TABLE `basket` (
  `id` int NOT NULL,
  `id_basket` int NOT NULL,
  `id_good` int NOT NULL,
  `id_order` int DEFAULT NULL,
  `id_user` int DEFAULT NULL,
  `count` int NOT NULL,
  `date_create_basket` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `basket`
--

INSERT INTO `basket` (`id`, `id_basket`, `id_good`, `id_order`, `id_user`, `count`, `date_create_basket`) VALUES
(1, 1, 1, 1, 2, 2, '2022-03-02 18:07:23'),
(2, 1, 3, 1, 2, 2, '2022-03-02 18:07:24'),
(3, 1, 6, 1, 2, 1, '2022-03-02 18:24:18'),
(6, 3, 7, 4, 2, 1, '2022-03-02 20:38:57'),
(7, 3, 8, 4, 2, 1, '2022-03-02 20:39:04'),
(8, 4, 2, 15, 2, 1, '2022-03-02 21:09:56'),
(9, 5, 2, 5, 4, 2, '2022-03-03 01:11:46'),
(10, 5, 7, 5, 4, 1, '2022-03-03 01:12:04'),
(11, 5, 4, 5, 4, 2, '2022-03-03 01:15:49'),
(12, 5, 3, 5, 4, 1, '2022-03-03 01:32:14'),
(13, 5, 8, 5, 4, 1, '2022-03-03 01:32:15'),
(23, 6, 2, 6, 5, 1, '2022-03-03 14:11:56'),
(24, 6, 3, 6, 5, 1, '2022-03-03 14:11:57'),
(25, 7, 3, 14, 5, 1, '2022-03-03 14:16:45'),
(26, 7, 5, 14, 5, 1, '2022-03-03 14:16:46'),
(27, 7, 6, 14, 5, 1, '2022-03-03 14:16:47'),
(49, 9, 4, 16, 5, 1, '2022-03-11 18:18:48'),
(50, 9, 20, 16, 5, 1, '2022-03-11 18:18:48'),
(51, 10, 20, NULL, 1, 4, '2022-03-11 18:35:22'),
(52, 10, 16, NULL, 1, 4, '2022-03-15 15:07:56'),
(53, 10, 3, NULL, 1, 1, '2022-03-15 15:08:19'),
(54, 8, 1, 17, 4, 1, '2022-03-15 19:02:58'),
(55, 8, 2, 17, 4, 1, '2022-03-15 19:03:00'),
(56, 11, 11, 18, 6, 1, '2022-03-15 20:08:07'),
(57, 11, 18, 18, 6, 1, '2022-03-15 20:08:10'),
(58, 11, 5, 18, 6, 1, '2022-03-15 20:08:12'),
(73, 12, 3, 19, 6, 1, '2022-03-15 21:01:26'),
(74, 12, 7, 19, 6, 1, '2022-03-15 21:01:42');

-- --------------------------------------------------------

--
-- Структура таблицы `categories`
--

CREATE TABLE `categories` (
  `id_category` int NOT NULL,
  `title` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `categories`
--

INSERT INTO `categories` (`id_category`, `title`) VALUES
(1, 'Спиннинги'),
(2, 'Катушки'),
(3, 'Приманки'),
(4, 'Плетеные шнуры'),
(5, 'Ящики и сумки'),
(6, 'Инструменты'),
(7, 'Одежда и обувь'),
(8, 'Аксессуары');

-- --------------------------------------------------------

--
-- Структура таблицы `goods`
--

CREATE TABLE `goods` (
  `id_good` int NOT NULL,
  `id_category` int DEFAULT NULL,
  `title` varchar(50) NOT NULL,
  `price` int NOT NULL,
  `img` varchar(50) NOT NULL,
  `info` text,
  `popularity` varchar(50) DEFAULT NULL,
  `date_create_good` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `goods`
--

INSERT INTO `goods` (`id_good`, `id_category`, `title`, `price`, `img`, `info`, `popularity`, `date_create_good`) VALUES
(1, 2, 'Катушка Daiwa 17 Exceler LT 3000C-OT', 7000, 'daiwa_exceler.jpg', 'Размер шпули: 3000<br>\r\nПередаточное отношение: 5.3:1<br>\r\nВес, гр: 235<br>\r\nКоличество подшипников: 6', 'y', '2022-03-02 17:21:03'),
(2, 2, 'Катушка Shimano Stradic FL19 2500', 12000, 'shimano.jpg', 'Размер шпули: 2500<br>\r\nПередаточное отношение: 5.3:1<br>\r\nВес, гр: 220<br>\r\nКоличество подшипников: 6+1', 'y', '2022-03-02 17:21:03'),
(3, 3, 'Блесна Kuusamo Professor 3 75/12', 500, 'professor.jpg', 'Вес, гр: 12<br>\r\nДлина, мм: 75', 'y', '2022-03-02 17:21:09'),
(4, 5, 'Сумка Aquatic СК14 с 7 коробками', 6500, 'aquatic.jpg', 'Сумка Aquatic СК-14 укомплектована 5 коробками FB-310 (306x228x39 мм) и 2 коробками FB-250 (255x188x39 мм).<br><br>\r\nГабаритные размеры ДхВхШ, см: 38х27х33', 'y', '2022-03-02 17:21:09'),
(5, 6, 'Набор инструментов Rapala', 1111, 'rapala.jpg', 'В наборе плоскогубцы 16 см, нож, кусачки', 'y', '2022-03-02 17:24:50'),
(6, 7, 'Вейдерсы Nordman Energy Plus', 9990, 'nordman.jpg', 'Вейдерсы из мембраны и неопрена Nordman Energy для демисезонной рыбалки. Защищают от холодной воды и при этом \"дышат\". Легкие и удобные.<br><br>\r\nВодонепроницаемость: 17 000 мм<br>\r\nДышащая способность: 6 000 г/кв.м/24 ч.', 'y', '2022-03-02 17:24:50'),
(7, 8, 'Бандана Buff Carp High UV Protection', 1110, 'buff.jpg', 'Бандана-гейтер Buff High UV разработана, чтобы обеспечивать максимальный комфорт и защиту в самую жаркую и солнечную погоду. Материал имеет специальную обработку, благодаря которой обеспечивает эффективную защиту от ультрафиолетовых лучей. Также, ткань хорошо вентилируется, отводит влагу от тела и очень быстро сохнет. Buff High UV можно носить во множестве различных  вариантов: как классический гейтер или повязку на голову, как бандану, шапочку, шейный платок и пр.', 'y', '2022-03-02 17:24:53'),
(8, 1, 'Спиннинг Crazy Fish Arion ASR762LS 3-12', 12300, 'cf_arion.jpg', 'Длина, см: 229<br>\r\nТест по приманкам, грамм: 3—12<br>\r\nТест по шнуру, РЕ: #0.3—#0.8<br>\r\nТип вершинки: солидовая<br>\r\nСтрой: экстрафаст<br>\r\nВес, грамм: 68<br>\r\nМатериал бланка: Toray nanometr 40T<br>\r\nКольца:	Fuji SiC Titanium<br>\r\nКатушкодержатель: Fuji VSS<br>\r\nТранспортировочная длина, см: 118', 'y', '2022-03-02 17:24:53'),
(9, 2, 'Катушка Daiwa Fuego 20 LT 3000-C', 8900, 'daiwa_fuego.jpg', 'Размер шпули: 3000<br>\r\nПередаточное отношение: 5.2:1<br>\r\nВес, гр: 215<br>\r\nКоличество подшипников: 6+1', 'y', '2022-03-05 15:51:54'),
(10, 2, 'Катушка Ryobi Ecusima 2000Vi', 4300, 'ryobi.jpg', 'Размер шпули: 2000<br>\r\nПередаточное отношение: 5.1:1<br>\r\nВес, гр: 262<br>\r\nКоличество подшипников: 4+1', NULL, '2022-03-05 17:26:03'),
(11, 1, 'Спиннинг Favorite X1 X1-702МН 7-28', 4100, 'favorite_x1.jpg', 'Длина, см: 213<br>\r\nТест по приманкам, грамм: 7-28<br>\r\nТест по шнуру, РЕ: #0.6—#1.2<br>\r\nТип вершинки: тубулярная<br>\r\nСтрой: фаст<br>\r\nВес, грамм: 146<br>\r\nМатериал бланка: Im24T<br>\r\nКольца:	-<br>\r\nКатушкодержатель: -<br>\r\nТранспортировочная длина, см: 112', NULL, '2022-03-05 17:30:17'),
(12, 1, 'Спиннинг Favorite Skyline SKYA-842H', 17000, 'favorite_skyline.jpg', 'Длина, см: 254<br>\r\nТест по приманкам, грамм: 20-60<br>\r\nТест по шнуру, РЕ: #2.5<br>\r\nТип вершинки: тубулярная<br>\r\nСтрой: экстрафаст<br>\r\nВес, грамм: 167<br>\r\nМатериал бланка: 40T<br>\r\nКольца:	-<br>\r\nКатушкодержатель: -<br>\r\nТранспортировочная длина, см: 132', NULL, '2022-03-05 17:35:37'),
(13, 1, 'Спиннинг Narval Argument 76H до 56 гр', 7350, 'narval.jpg', 'Длина, см: 230<br>\r\nТест по приманкам, грамм: до 56<br>\r\nТест по шнуру, РЕ: #2.5<br>\r\nТип вершинки: тубулярная<br>\r\nСтрой: экстрафаст<br>\r\nВес, грамм: 132<br>\r\nМатериал бланка: HMC<br>\r\nКольца:	-<br>\r\nКатушкодержатель: -<br>\r\nТранспортировочная длина, см: 119', NULL, '2022-03-05 17:35:37'),
(14, 1, 'Удилище Crocodile 270 см 100-250', 1500, 'crocodile.jpg', 'Длина, см: 270<br>\r\nТест по приманкам, грамм: 100-250<br>\r\nТест по шнуру, -<br>\r\nТип вершинки: -<br>\r\nСтрой: -<br>\r\nВес, грамм: 650<br>\r\nМатериал бланка: -<br>\r\nКольца:	-<br>\r\nКатушкодержатель: -<br>\r\nТранспортировочная длина, см: -', NULL, '2022-03-05 17:41:23'),
(15, 3, 'Блесна Mepps Syclops №2 phospho', 750, 'mepps_syclops.jpg', 'Вес, гр: 12<br>\r\nДлина, мм: 75', NULL, '2022-03-05 17:58:49'),
(17, 3, 'Блесна Abu Garcia Toby 75/15', 555, 'toby.jpg', 'Вес, гр: 15<br>\nДлина, мм: 75', 'n', '2022-03-05 18:00:39'),
(18, 4, 'Шнур Sunline Siglon X4150м PE 0,4', 1250, 'sunline.jpeg', 'Длина, м: 150<br>\r\nКоличество жил: 4<br>\r\nТолщина, PE: 0.4<br>\r\nРазрывная нагрузка, lb: 6', NULL, '2022-03-05 18:06:19'),
(19, 4, 'Шнур YGK X-Braid Upgrade X8 200м PE 0,8', 3200, 'ygk.jpeg', 'Длина, м: 200<br>\r\nКоличество жил: 8<br>\r\nТолщина, PE: 0.8<br>\r\nРазрывная нагрузка, lb: 14', NULL, '2022-03-05 18:06:19'),
(23, 5, 'Ящик рыболовный Flambeau', 3500, 'flambeau.jpeg', '-', 'n', '2022-03-15 20:15:40');

-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id_order` int NOT NULL,
  `id_basket` int NOT NULL,
  `status` int NOT NULL,
  `sum` int NOT NULL,
  `date_create_order` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id_order`, `id_basket`, `status`, `sum`, `date_create_order`) VALUES
(1, 1, 4, 24990, '2022-03-02 18:37:17'),
(4, 3, 2, 13410, '2022-03-02 20:39:08'),
(5, 5, 1, 50910, '2022-03-03 01:32:31'),
(6, 6, 2, 0, '2022-03-03 14:03:50'),
(7, 6, 1, 0, '2022-03-03 14:03:51'),
(8, 6, 1, 0, '2022-03-03 14:03:57'),
(9, 6, 1, 0, '2022-03-03 14:04:35'),
(10, 6, 1, 0, '2022-03-03 14:04:43'),
(11, 6, 1, 0, '2022-03-03 14:05:48'),
(12, 6, 1, 0, '2022-03-03 14:05:54'),
(13, 6, 1, 12500, '2022-03-03 14:12:02'),
(14, 7, 2, 11690, '2022-03-03 14:16:51'),
(15, 4, 1, 12000, '2022-03-11 18:18:18'),
(16, 9, 3, 11300, '2022-03-11 18:18:50'),
(17, 8, 1, 19000, '2022-03-15 19:03:16'),
(18, 11, 1, 6550, '2022-03-15 20:08:15'),
(19, 12, 1, 1610, '2022-03-15 21:01:48');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id_user` int NOT NULL,
  `fio` varchar(50) DEFAULT NULL,
  `login` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `date_create_user` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id_user`, `fio`, `login`, `password`, `email`, `phone`, `date_create_user`) VALUES
(1, NULL, 'admin', 'admin', NULL, NULL, '2022-03-02 16:42:59'),
(2, NULL, 'a1', 'a1', '', '', '2022-03-02 18:07:17'),
(4, NULL, 'a2', 'a2', '', '', '2022-03-03 01:11:31'),
(5, NULL, 'a3', 'a3', '', '', '2022-03-03 14:10:57'),
(6, NULL, 'b1', 'b1', '', '', '2022-03-15 19:25:50');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `basket`
--
ALTER TABLE `basket`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id_category`);

--
-- Индексы таблицы `goods`
--
ALTER TABLE `goods`
  ADD PRIMARY KEY (`id_good`);

--
-- Индексы таблицы `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id_order`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `basket`
--
ALTER TABLE `basket`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT для таблицы `categories`
--
ALTER TABLE `categories`
  MODIFY `id_category` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `goods`
--
ALTER TABLE `goods`
  MODIFY `id_good` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT для таблицы `orders`
--
ALTER TABLE `orders`
  MODIFY `id_order` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
